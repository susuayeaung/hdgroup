const AWS = require('aws-sdk');
AWS.config.update({
    region: 'us-east-1'
})
const util = require('../utils/util');
const bcrypt = require('bcryptjs');

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const userTable = 'hdgroup-users';

async function register(userInfo){
    const name = userInfo.name;
    const email = userInfo.email;
    const username = userInfo.username;
    const password = userInfo.password;
    const image = userInfo.image;

    if(!username || !name || !email || !password){
        return util.buildResponse(401, {
            message: 'All fields are required!'
        })
    }

    const dynamoUser = await getUser(username.toLowerCase().trim());
    if(dynamoUser && dynamoUser.username){
        return util.buildResponse(401, {
            message: 'Username is already existed. Please choose the different username.'
        })
    }

    const encryptedPW = bcrypt.hashSync(password.trim(), 10);
    
    const isImage = require('is-image');
    if(isImage(image) == false){
        return util.buildResponse(401, {
            message: 'Invalid image file type!'
        })
    }

    const user = {
        name: name,
        email: email,
        username: username.toLowerCase().trim(),
        password: encryptedPW,
        image: image
    }

    const saveUserResponse = await saveUser(user);
    if(!saveUserResponse){
        util.buildResponse(503, { message : 'Server Error! Please try again later.' });
    }
    
    return util.buildResponse(200, { username: username });
}

async function getUser(username){
    const params = {
        TableName: userTable,
        Key: {
            username: username
        }
    }

    return await dynamoDb.get(params).promise().then(response => {
        return response.Item;
    }, error => {
        console.error("There is an error in getting user: ", error);
    })
}

async function saveUser(user){
    const params = {
        TableName: userTable,
        Item: user
    }
    return await dynamoDb.put(params).promise().then(() => {
        return true;
    }, error => {
        console.error("There is an error in saving user: ", error);
    });
}

module.exports.register = register;